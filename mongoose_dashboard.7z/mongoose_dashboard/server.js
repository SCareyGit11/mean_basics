var express = require('express');
// Create an Express App
var app = express();
var pathToRegexp = require('path-to-regexp');
var mongoose = require('mongoose');
// This is how we connect to the mongodb database using mongoose -- "basic_mongoose" is the name of
//   our db in mongodb -- this should match the name of the db you are going to use for your project.
mongoose.connect('mongodb://localhost/mongoose_dashboard');
var AnimalSchema = new mongoose.Schema({
 name: String,
 age: Number,
 weight: Number,
 food: String
})
mongoose.model('Animal', AnimalSchema); // We are setting this Schema in our Models as 'User'
var Animal = mongoose.model('Animal') // We are retrieving this Schema from our Models, named 'User'
// Require body-parser (to receive post data from clients)
var bodyParser = require('body-parser');
// Integrate body-parser with our App
app.use(bodyParser.urlencoded({ extended: true }));
// Require path
var path = require('path');
// Setting our Static Folder Directory
app.use(express.static(path.join(__dirname, './static')));
// Setting our Views Folder Directory
app.set('views', path.join(__dirname, './views'));
// Setting our View Engine set to EJS
app.set('view engine', 'ejs');
// Routes
// Root Request
app.get('/', function(req, res) {
    // This is where we will retrieve the animals from the database and include them in the view page we will be rendering.
    		// The root route -- we want to get all of the users from the database and then render the index view passing it all of the users

  Animal.find({}, function(err, animals) {
    // This is the method that finds all of the users from the database
    // Notice how the first parameter is the options for what to find and the second is the
    //   callback function that has an error (if any) and all of the users
    // Keep in mind that everything you want to do AFTER you get the users from the database must
    //   happen inside of this callback for it to be synchronous 
    // Make sure you handle the case when there is an error, as well as the case when there is no error
    	if(err) {
      console.log('something went wrong from database');
    }
    	else { // else console.log that we did well and then redirect to the root route
      console.log('successfully called an animal!');
      console.log(animals);
	     res.render('index', {animals: animals});
		}
 
	 
   
	})
})
//////////////////////// GET THE ID FROM INDEX AND DELETE //////////////////////////////////////

app.get("/animals/:id/destroy", function(req, res) {
//app.get("/\w*/destroy", function(req, res) {
	console.log(req.params);

	//var id = req.body.id;
  Animal.remove({_id: req.params.id}, function(err, animals) {
    // This is the method that finds all of the users from the database
    // Notice how the first parameter is the options for what to find and the second is the
    //   callback function that has an error (if any) and all of the users
    // Keep in mind that everything you want to do AFTER you get the users from the database must
    //   happen inside of this callback for it to be synchronous 
    // Make sure you handle the case when there is an error, as well as the case when there is no error
    	if(err) {
      console.log('err');
    }
    	else { // else console.log that we did well and then redirect to the root route
      console.log('successfully destroyed an animal!');
      
	     res.redirect('/');
		}
 
	 
   
	})
})


//////////////////////// GET THE ID FROM INDEX AND send to EDIT PAGE //////////////////////////////////////

app.get("/animals/:id/edit", function(req, res) {

  

  Animal.find({_id: req.params.id}, function(err, animals) {
    	if(err) {
      console.log('err');
    }
    	else { // else console.log that we did well and then redirect to the root route
      console.log(animals);
      
	     res.render('edit', {animals: animals});
		}
 
	 
   
	})
})

//////////////////////// GET THE ID FROM EDIT PAGE AND FINALIZE EDIT //////////////////////////////////////

app.post("/animals/:id/confirm", function(req, res) {


	// find the user with id 4
	// update username to starlord 88
	//User.findByIdAndUpdate(4, { username: 'starlord88' }, function(err, user) {		
  	//if (err) throw err;

  	// we have the updated user returned to us
  	//console.log(user);
	//};
	console.log({_id: req.params.id});
  Animal.update({_id: req.params.id}, req.body, function(err, animal) {
    	if(err) {
      console.log('err');
    }
    	else { // else console.log that we did well and then redirect to the root route
      console.log('successfully altered an animal!');
      
	     res.redirect('/');
		}
 
	 
   
	})
})




// Add User Request 
app.post('/animals', function(req, res) {
    console.log("POST DATA", req.body);
    // This is where we would add the user from req.body to the database.
    // create a new User with the name and age corresponding to those from req.body
  	// Use native promises
	mongoose.Promise = global.Promise;
  	var animal = new Animal({name: req.body.name, age: req.body.age, weight: req.body.weight, food: req.body.food});
  	// Try to save that new user to the database (this is the method that actually inserts into the db) and run a callback function with an error (if any) from the operation.
  	animal.save(function(err) {
    // if there is an error console.log that something went wrong!
    if(err) {
      console.log('something went wrong');
    } 
    else { // else console.log that we did well and then redirect to the root route
      console.log('successfully added an animal!');

	    res.redirect('/');
		}
	})

	
})	
	    

// Setting our Server to Listen on Port: 8000
app.listen(8000, function() {
    console.log("listening on port 8000");
})